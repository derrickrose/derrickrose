def handler(event, context):
    print("hello world from terraform")
    return "hello world"
