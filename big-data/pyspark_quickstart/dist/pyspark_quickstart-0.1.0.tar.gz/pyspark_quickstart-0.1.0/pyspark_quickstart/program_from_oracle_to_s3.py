""" Module used to load TV programs from Oracle and save them to AWS s3 """

import pyspark
import sys
from pyspark_quickstart.initial_conf import InitialConf
from pyspark.sql import SparkSession


def main():
    return sys.argv[1:]


if __name__ == "__main__":
    execution_context = InitialConf.from_spark_submit_arguments(main())
    print(execution_context.get_program_output_path())
    # findspark.init()
    sc = pyspark.SparkContext.getOrCreate()
    stringJSONRDD = sc.parallelize((""" 
      { "id": "123",
        "name": "Katie",
        "age": 19,
        "eyeColor": "brown"
      }"""))

    spark_session: SparkSession = SparkSession.builder \
        .master("local") \
        .appName("program_from_oracle_to_s3").getOrCreate()

    programDataFrame = spark_session.read.json("../source/*")
    print(programDataFrame.show())

    """ todo logical according to execution_type (full/delta loading) """

    """ todo load programs from oracle """

    """ todo read existing programs on AWS s3 """
    """ todo union AWS s3 programs with loaded programs """
    """ todo filter/sort/deduplicate programs """
    """ todo save programs to AWS s3 """
